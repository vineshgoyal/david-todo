import React, { useEffect, useState } from "react"
import { BaseApi } from "./BaseUrl"


export default function UserDetail2(props) {

    var [todotitle, selectfunc] = useState()

    function changeTitle(event) {

        selectfunc(event.target.value)
    }



    return (

        <>
            <h2>UserDetail is below:</h2><br />
            <input value={props.selectedTodo.title} /> <br />
            <button type="button" class="btn btn-sm ml-1 bg-primary mt-2" onChange={changeTitle} >
                Submit
                    </button>


        </>
    )

}