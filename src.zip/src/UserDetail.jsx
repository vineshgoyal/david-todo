import React, { useEffect, useState } from "react"
import { BaseApi } from "./BaseUrl"


export default function UserDetail(props) {

    var [todoSingle, selectfunc] = useState({})
    var [todotitle, editTitle] = useState("")
    useEffect(function () {

        if (props.selectedTodo != undefined) {

            BaseApi.get("todos/" + props.selectedTodo).then((res) => {

                //console.log({ ...res.data })

                selectfunc({ ...res.data })


            })
        }

    }, [props.selectedTodo])

    console.log(todoSingle)

    function add() {
        let singleTodo = {
            title: todoSingle.title,
            complete: false
        }

        BaseApi.patch("todos/" + props.selectedTodo, { title: todoSingle.title }).then((res) => { })


    }

    function changeTitle(event) {
        todoSingle.title = event.target.value
        console.log(todoSingle.title)
        selectfunc({ ...todoSingle })

    }

    if (props.selectedTodo == undefined) {
        return null
    }




    return (

        <div className="jumbotron bg-warning">
            <h2>UserDetail of Roll NO. {props.selectedTodo}</h2>
            <input value={todoSingle.title} onChange={changeTitle} /> <br />
            <button type="button" class="btn btn-sm ml-1 bg-primary mt-2" onClick={add} >
                Submit
                    </button>

        </div>
    )

}